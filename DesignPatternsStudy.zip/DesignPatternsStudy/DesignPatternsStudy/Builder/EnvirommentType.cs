﻿
namespace DesignPatternsStudy.Builder
{
    public enum EnvirommentType
    {
        Vacuum,
        Extreme,
        Balanced
    }
}
