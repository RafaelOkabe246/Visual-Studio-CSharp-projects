﻿namespace DesignPatternsStudy.Factory_Pattern_Classes
{
    public enum ArmorType
    {
        Padded,
        Reflactive,
        Normal
    }
}
