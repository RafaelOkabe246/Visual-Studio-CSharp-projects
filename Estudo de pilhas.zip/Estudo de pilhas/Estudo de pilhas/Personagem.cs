﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Estudo_de_pilhas
{
    public class Personagem
    {
        public string nome;

        public Personagem()
        {

        }
    }
}
