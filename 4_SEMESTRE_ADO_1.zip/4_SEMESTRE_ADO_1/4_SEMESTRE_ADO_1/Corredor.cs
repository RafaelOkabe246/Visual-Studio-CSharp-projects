﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4_SEMESTRE_ADO_1
{
    class Corredor
    {
        public string corredorNome;
        public string[] itens =
            {  };

        public Corredor(string _corredorNome)
        {
            this.corredorNome = _corredorNome;
        }

    }
}
